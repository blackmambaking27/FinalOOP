/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

import BusinessLayer.User.UserType;
import DataAccessLayer.ScooterDAO;
import DataAccessLayer.ScooterDAOImp;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author sethb
 */
public class ViewAccountAction implements Action {

    private final ScooterDAO scooterDAO = new ScooterDAOImp();

    @Override
public void execute(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    HttpSession session = request.getSession(false);
    User current = (session == null) ? null : (User) session.getAttribute("currentUser");

    if (current == null) {
        response.sendRedirect("controller?action=showLogin");
        return;
    }

    UserType type = current.getUserType();
    if (type == null) {
        type = UserType.USER;
    }

    try {
        request.setAttribute("currentUser", current);

        switch (type) {
            case USER: {
                double debits  = 20.0 + (current.getId() * 3.5);
                double credits = 2.0 * (current.getId() % 3);
                double amountToPay = Math.max(0.0, debits - credits);

                request.setAttribute("mode", "USER");
                request.setAttribute("debits", debits);
                request.setAttribute("credits", credits);
                request.setAttribute("amountToPay", amountToPay);
                break;
            }
            case SPONSOR: {
                List<Scooter> mine = scooterDAO.findBySponsor(current.getId());
                int scooterCount = mine.size();
                double credits = scooterCount * 15.0;

                request.setAttribute("mode", "SPONSOR");
                request.setAttribute("scooterCount", scooterCount);
                request.setAttribute("credits", credits);
                break;
            }
            case MAINTAINER: {
                List<Scooter> all = scooterDAO.findAll();
                int fleetSize = all.size();
                int tasksHandled = (current.getId() * 4 + fleetSize) % 20;
                double credits = tasksHandled * 3.0;

                request.setAttribute("mode", "MAINTAINER");
                request.setAttribute("fleetSize", fleetSize);
                request.setAttribute("tasksHandled", tasksHandled);
                request.setAttribute("credits", credits);
                break;
            }
            default:
                request.setAttribute("mode", "USER");
                double debits  = 20.0 + (current.getId() * 3.5);
                double credits = 2.0 * (current.getId() % 3);
                double amountToPay = Math.max(0.0, debits - credits);
                request.setAttribute("debits", debits);
                request.setAttribute("credits", credits);
                request.setAttribute("amountToPay", amountToPay);
        }

        request.getRequestDispatcher("/WEB-INF/jsp/account.jsp")
               .forward(request, response);

    } catch (Exception e) {
        throw new ServletException(e);
    }
}

}