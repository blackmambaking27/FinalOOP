/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

import DataAccessLayer.ScooterDAO;
import DataAccessLayer.ScooterDAOImp;
import BusinessLayer.User.UserType;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author sethb
 */
public class RegisterScooterAction implements Action {

    private final ScooterDAO scooterDAO = new ScooterDAOImp();

    @Override
public void execute(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    HttpSession session = request.getSession(false);
    User current = (session == null) ? null : (User) session.getAttribute("currentUser");

    if (current == null || current.getUserType() != UserType.SPONSOR) {
        response.sendRedirect("controller?action=showLogin");
        return;
    }

    try {
        String vehicleNumber = request.getParameter("vehicleNumber");
        String make          = request.getParameter("make");
        String model         = request.getParameter("model");
        String color         = request.getParameter("color");
        int batteryCap       = Integer.parseInt(request.getParameter("batteryCapacity"));

        Scooter scooter = new Scooter.Builder()
                .vehicleNumber(vehicleNumber)
                .make(make)
                .model(model)
                .color(color)
                .batteryCapacity(batteryCap)
                .sponsorUserId(current.getId())
                .build();

        scooterDAO.create(scooter);

        // On success, show form again with success message
        request.setAttribute("message", "Scooter registered successfully!");
        request.setAttribute("currentUser", current);
        request.getRequestDispatcher("/WEB-INF/jsp/registerScooter.jsp")
               .forward(request, response);

    } catch (Exception e) {
        e.printStackTrace();
        request.setAttribute("error", "Error during scooter registration: " + e.getMessage());
        request.setAttribute("currentUser", current);
        request.getRequestDispatcher("/WEB-INF/jsp/registerScooter.jsp")
               .forward(request, response);
    }
}

}