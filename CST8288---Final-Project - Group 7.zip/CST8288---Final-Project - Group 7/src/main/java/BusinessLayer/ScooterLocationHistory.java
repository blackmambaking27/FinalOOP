package BusinessLayer;

import java.time.LocalDateTime;

public class ScooterLocationHistory {

    private final int historyId;
    private final int scooterId;
    private final Integer stationId;
    private final String locationDescription;
    private final boolean inTransit;
    private final LocalDateTime recordedAt;

    private ScooterLocationHistory(Builder b) {
        this.historyId = b.historyId;
        this.scooterId = b.scooterId;
        this.stationId = b.stationId;
        this.locationDescription = b.locationDescription;
        this.inTransit = b.inTransit;
        this.recordedAt = b.recordedAt;
    }

    public static class Builder {
        private int historyId;
        private int scooterId;
        private Integer stationId;
        private String locationDescription;
        private boolean inTransit;
        private LocalDateTime recordedAt;

        public Builder historyId(int id) { this.historyId = id; return this; }
        public Builder scooterId(int sid) { this.scooterId = sid; return this; }
        public Builder stationId(Integer id) { this.stationId = id; return this; }
        public Builder locationDescription(String d) { this.locationDescription = d; return this; }
        public Builder inTransit(boolean t) { this.inTransit = t; return this; }
        public Builder recordedAt(LocalDateTime t) { this.recordedAt = t; return this; }

        public ScooterLocationHistory build() { return new ScooterLocationHistory(this); }
    }

    public int getHistoryId() { return historyId; }
    public int getScooterId() { return scooterId; }
    public Integer getStationId() { return stationId; }
    public String getLocationDescription() { return locationDescription; }
    public boolean isInTransit() { return inTransit; }
    public LocalDateTime getRecordedAt() { return recordedAt; }
}
