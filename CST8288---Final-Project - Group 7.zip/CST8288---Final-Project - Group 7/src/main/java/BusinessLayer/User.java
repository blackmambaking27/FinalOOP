/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

/**
 *
 * @author sethb
 */
public class User {
    public enum UserType { USER, SPONSOR, MAINTAINER, ADMIN }

    private int id;
    private String name;
    private String email;
    private String password;
    private UserType userType;

    // Private constructor – only Builder can create
    private User(Builder b) {
        this.id = b.id;
        this.name = b.name;
        this.email = b.email;
        this.password = b.password;
        this.userType = b.userType;
    }

    // This method is the builder pattern
    public static class Builder {
        private int id;
        private String name;
        private String email;
        private String password;
        private UserType userType;

        public Builder id(int id) {
            this.id = id;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder userType(UserType userType) {
            this.userType = userType;
            return this;
        }

        public User build() {
            return new User(this);
        }
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public UserType getUserType() {
        return userType;
    }
}
