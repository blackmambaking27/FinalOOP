package BusinessLayer;

import BusinessLayer.User.UserType;
import DataAccessLayer.ScooterDAO;
import DataAccessLayer.ScooterDAOImp;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ViewSponsorScootersAction implements Action {

    private final ScooterDAO scooterDAO = new ScooterDAOImp();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User current = (session == null) ? null : (User) session.getAttribute("currentUser");

        // Only Sponsors can view this
        if (current == null || current.getUserType() != UserType.SPONSOR) {
            response.sendRedirect("controller?action=showLogin");
            return;
        }

        try {
            // Load this sponsor's scooters from the DB
            List<Scooter> scooters = scooterDAO.findBySponsor(current.getId());

            // Make them available to the JSP
            request.setAttribute("scooters", scooters);
            request.setAttribute("currentUser", current);

            // Forward to JSP
            request.getRequestDispatcher("/WEB-INF/jsp/sponsorScooter.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            throw new ServletException("Error loading sponsor scooters", e);
        }
    }
}
