package BusinessLayer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class DashboardAction implements Action {

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User u = (session == null) ? null : (User) session.getAttribute("currentUser");

        // If not logged in, go back to login
        if (u == null) {
            response.sendRedirect("controller?action=showLogin");
            return;
        }

        // Just forward to JSP; JSP will read currentUser from session
        request.getRequestDispatcher("/WEB-INF/jsp/dashboard.jsp")
               .forward(request, response);
    }
}
