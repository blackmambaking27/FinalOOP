/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

import BusinessLayer.User.UserType;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author sethb
 */
public class ShowRegisterScooterAction implements Action {

  @Override
public void execute(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    HttpSession session = request.getSession(false);
    User current = (session == null) ? null : (User) session.getAttribute("currentUser");

    if (current == null || current.getUserType() != UserType.SPONSOR) {
        response.sendRedirect("controller?action=showLogin");
        return;
    }

    request.setAttribute("currentUser", current);
    request.getRequestDispatcher("/WEB-INF/jsp/registerScooter.jsp")
           .forward(request, response);
}


}