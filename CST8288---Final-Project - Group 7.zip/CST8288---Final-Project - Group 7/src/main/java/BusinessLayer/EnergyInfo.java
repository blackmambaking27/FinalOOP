/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

/**
 *
 * @author sethb
 * Adapter Pattern – Target interface.
 * Represents energy-related info for a scooter, used by the energy report.
 */
public interface EnergyInfo {

    String getVehicleNumber();
    int getBatteryCapacity();
    int getCurrentChargePercent();
    int getMinutesToFull();
    int getEstimatedRangeKm();
}