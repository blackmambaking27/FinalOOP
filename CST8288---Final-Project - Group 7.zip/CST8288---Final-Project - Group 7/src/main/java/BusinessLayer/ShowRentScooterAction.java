package BusinessLayer;

import BusinessLayer.User.UserType;
import DataAccessLayer.ScooterDAO;
import DataAccessLayer.ScooterDAOImp;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Shows a list of AVAILABLE scooters that a USER can rent.
 */
public class ShowRentScooterAction implements Action {

    private final ScooterDAO scooterDAO = new ScooterDAOImp();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User current = (session == null) ? null : (User) session.getAttribute("currentUser");

        // Only regular USERS can rent scooters
        if (current == null || current.getUserType() != UserType.USER) {
            response.sendRedirect("controller?action=showLogin");
            return;
        }

        try {
            List<Scooter> all = scooterDAO.findAll();
            List<Scooter> available = new ArrayList<>();

            for (Scooter s : all) {
                if (s.getStatus() == Scooter.Status.AVAILABLE) {
                    available.add(s);
                }
            }

            request.setAttribute("currentUser", current);
            request.setAttribute("scooters", available);

            request.getRequestDispatcher("/WEB-INF/jsp/rentScooter.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            throw new ServletException("Error loading scooters for rent", e);
        }
    }
}
