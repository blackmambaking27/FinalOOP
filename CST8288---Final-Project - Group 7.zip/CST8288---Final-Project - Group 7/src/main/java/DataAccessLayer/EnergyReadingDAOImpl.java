package DataAccessLayer;

import BusinessLayer.EnergyReading;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class EnergyReadingDAOImpl implements EnergyReadingDAO {

    private final DBConnectionManager connectionManager;

    public EnergyReadingDAOImpl() {
        this(new DBConnectionManager());
    }

    public EnergyReadingDAOImpl(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(EnergyReading reading) throws Exception {
        String sql = "INSERT INTO energy_reading " +
                "(scooter_id, reading_time, charge_percent, time_to_full_min, energy_used_kwh) " +
                "VALUES (?,?,?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, reading.getScooterId());
            ps.setTimestamp(2, Timestamp.valueOf(reading.getReadingTime()));
            ps.setInt(3, reading.getChargePercent());

            if (reading.getTimeToFullMinutes() != null) {
                ps.setInt(4, reading.getTimeToFullMinutes());
            } else {
                ps.setNull(4, Types.INTEGER);
            }

            if (reading.getEnergyUsedKwh() != null) {
                ps.setBigDecimal(5, reading.getEnergyUsedKwh());
            } else {
                ps.setNull(5, Types.DECIMAL);
            }

            ps.executeUpdate();
            // No reading.setReadingId(...)
        }
    }

    @Override
    public EnergyReading findLatestByScooterId(int scooterId) throws Exception {
        String sql = "SELECT * FROM energy_reading " +
                     "WHERE scooter_id = ? ORDER BY reading_time DESC LIMIT 1";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooterId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<EnergyReading> findByScooterId(int scooterId) throws Exception {
        List<EnergyReading> list = new ArrayList<>();
        String sql = "SELECT * FROM energy_reading WHERE scooter_id = ? ORDER BY reading_time DESC";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooterId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    private EnergyReading mapRow(ResultSet rs) throws Exception {
        Timestamp ts = rs.getTimestamp("reading_time");
        LocalDateTime time = ts != null ? ts.toLocalDateTime() : null;

        return new EnergyReading.Builder()
                .readingId(rs.getInt("reading_id"))
                .scooterId(rs.getInt("scooter_id"))
                .readingTime(time)
                .chargePercent(rs.getInt("charge_percent"))
                .timeToFullMinutes((Integer) rs.getObject("time_to_full_min"))
                .energyUsedKwh(rs.getBigDecimal("energy_used_kwh"))
                .build();
    }
}
