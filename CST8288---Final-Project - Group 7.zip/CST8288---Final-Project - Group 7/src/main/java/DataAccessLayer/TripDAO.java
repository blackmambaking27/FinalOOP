package DataAccessLayer;

import BusinessLayer.Trip;
import java.util.List;

public interface TripDAO {

    void create(Trip trip) throws Exception;

    Trip findById(int tripId) throws Exception;

    List<Trip> findByUserId(int userId) throws Exception;

    List<Trip> findByScooterId(int scooterId) throws Exception;

    List<Trip> findAll() throws Exception;
}
