package DataAccessLayer;

import BusinessLayer.MaintenanceAlert;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MaintenanceAlertDAOImpl implements MaintenanceAlertDAO {

    private final DBConnectionManager connectionManager;

    public MaintenanceAlertDAOImpl() {
        this(new DBConnectionManager());
    }

    public MaintenanceAlertDAOImpl(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(MaintenanceAlert alert) throws Exception {
        String sql = "INSERT INTO maintenance_alert " +
                "(scooter_id, created_at, alert_type, description, is_active) " +
                "VALUES (?,?,?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, alert.getScooterId());
            ps.setTimestamp(2, Timestamp.valueOf(alert.getCreatedAt()));
            ps.setString(3, alert.getAlertType());
            ps.setString(4, alert.getDescription());
            ps.setBoolean(5, alert.isActive());

            ps.executeUpdate();
            // ⚠️ No alert.setAlertId(...); MaintenanceAlert is immutable
        }
    }

    @Override
    public MaintenanceAlert findById(int alertId) throws Exception {
        String sql = "SELECT * FROM maintenance_alert WHERE alert_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, alertId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<MaintenanceAlert> findActiveByScooterId(int scooterId) throws Exception {
        List<MaintenanceAlert> list = new ArrayList<>();
        String sql = "SELECT * FROM maintenance_alert WHERE scooter_id = ? AND is_active = TRUE";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooterId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public List<MaintenanceAlert> findAllActive() throws Exception {
        List<MaintenanceAlert> list = new ArrayList<>();
        String sql = "SELECT * FROM maintenance_alert WHERE is_active = TRUE";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    @Override
    public void update(MaintenanceAlert alert) throws Exception {
        String sql = "UPDATE maintenance_alert " +
                     "SET scooter_id = ?, created_at = ?, alert_type = ?, " +
                     "    description = ?, is_active = ? " +
                     "WHERE alert_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, alert.getScooterId());
            ps.setTimestamp(2, Timestamp.valueOf(alert.getCreatedAt()));
            ps.setString(3, alert.getAlertType());
            ps.setString(4, alert.getDescription());
            ps.setBoolean(5, alert.isActive());
            ps.setInt(6, alert.getAlertId());

            ps.executeUpdate();
        }
    }

    private MaintenanceAlert mapRow(ResultSet rs) throws Exception {
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime createdAt = ts != null ? ts.toLocalDateTime() : null;

        return new MaintenanceAlert.Builder()
                .alertId(rs.getInt("alert_id"))
                .scooterId(rs.getInt("scooter_id"))
                .createdAt(createdAt)
                .alertType(rs.getString("alert_type"))
                .description(rs.getString("description"))
                .active(rs.getBoolean("is_active"))
                .build();
    }
}
