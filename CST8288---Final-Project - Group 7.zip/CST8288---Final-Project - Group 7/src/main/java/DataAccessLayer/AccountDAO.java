package DataAccessLayer;

import BusinessLayer.Account;
import java.util.List;

public interface AccountDAO {

    void create(Account account) throws Exception;

    Account findById(int accountId) throws Exception;

    Account findByUserId(int userId) throws Exception;

    void update(Account account) throws Exception;

    List<Account> findAll() throws Exception;
}
