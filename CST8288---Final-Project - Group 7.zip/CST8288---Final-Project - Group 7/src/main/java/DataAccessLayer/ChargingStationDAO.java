package DataAccessLayer;

import BusinessLayer.ChargingStation;
import java.util.List;

public interface ChargingStationDAO {

    void create(ChargingStation station) throws Exception;

    ChargingStation findById(int stationId) throws Exception;

    List<ChargingStation> findAll() throws Exception;
}
