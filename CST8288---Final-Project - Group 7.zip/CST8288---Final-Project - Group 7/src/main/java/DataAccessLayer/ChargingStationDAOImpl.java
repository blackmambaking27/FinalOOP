package DataAccessLayer;

import BusinessLayer.ChargingStation;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChargingStationDAOImpl implements ChargingStationDAO {

    private final DBConnectionManager connectionManager;

    public ChargingStationDAOImpl() {
        this(new DBConnectionManager());
    }

    public ChargingStationDAOImpl(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(ChargingStation station) throws Exception {
        String sql = "INSERT INTO charging_station (name, location_desc, max_capacity) " +
                     "VALUES (?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, station.getName());
            ps.setString(2, station.getLocationDescription());
            ps.setInt(3, station.getMaxCapacity());

            ps.executeUpdate();
            // No station.setStationId(...)
        }
    }

    @Override
    public ChargingStation findById(int stationId) throws Exception {
        String sql = "SELECT * FROM charging_station WHERE station_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, stationId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<ChargingStation> findAll() throws Exception {
        List<ChargingStation> list = new ArrayList<>();
        String sql = "SELECT * FROM charging_station";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private ChargingStation mapRow(ResultSet rs) throws Exception {
        return new ChargingStation.Builder()
                .stationId(rs.getInt("station_id"))
                .name(rs.getString("name"))
                .locationDescription(rs.getString("location_desc"))
                .maxCapacity(rs.getInt("max_capacity"))
                .build();
    }
}
