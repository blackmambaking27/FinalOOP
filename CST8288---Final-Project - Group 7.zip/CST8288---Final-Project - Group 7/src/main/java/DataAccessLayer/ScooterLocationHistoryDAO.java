package DataAccessLayer;

import BusinessLayer.ScooterLocationHistory;
import java.util.List;

public interface ScooterLocationHistoryDAO {

    void create(ScooterLocationHistory history) throws Exception;

    List<ScooterLocationHistory> findByScooterId(int scooterId) throws Exception;

    ScooterLocationHistory findLatestByScooterId(int scooterId) throws Exception;
}
