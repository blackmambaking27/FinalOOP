package DataAccessLayer;

import BusinessLayer.EnergyReading;
import java.util.List;

public interface EnergyReadingDAO {

    void create(EnergyReading reading) throws Exception;

    EnergyReading findLatestByScooterId(int scooterId) throws Exception;

    List<EnergyReading> findByScooterId(int scooterId) throws Exception;
}
