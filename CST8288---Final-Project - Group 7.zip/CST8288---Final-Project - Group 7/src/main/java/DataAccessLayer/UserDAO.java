package DataAccessLayer;

import BusinessLayer.User;
import java.util.List;

/**
 * Data Access Object interface for User entity.
 */
public interface UserDAO {
    void create(User user) throws Exception;

    User findByEmail(String email) throws Exception;

    User findById(int id) throws Exception;

    List<User> findAll() throws Exception;
}
