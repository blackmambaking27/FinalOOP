package BusinessLayer;

import java.time.LocalDate;

public class MaintenanceTask {

    public enum Status { PLANNED, IN_PROGRESS, COMPLETED, CANCELLED }

    private final int taskId;
    private final Integer alertId;
    private final int scooterId;
    private final Integer maintainerId;
    private final LocalDate scheduledDate;
    private final LocalDate completedDate;
    private final Status status;
    private final String notes;

    private MaintenanceTask(Builder b) {
        this.taskId = b.taskId;
        this.alertId = b.alertId;
        this.scooterId = b.scooterId;
        this.maintainerId = b.maintainerId;
        this.scheduledDate = b.scheduledDate;
        this.completedDate = b.completedDate;
        this.status = b.status;
        this.notes = b.notes;
    }

    public static class Builder {
        private int taskId;
        private Integer alertId;
        private int scooterId;
        private Integer maintainerId;
        private LocalDate scheduledDate;
        private LocalDate completedDate;
        private Status status = Status.PLANNED;
        private String notes;

        public Builder taskId(int id) { this.taskId = id; return this; }
        public Builder alertId(Integer aid) { this.alertId = aid; return this; }
        public Builder scooterId(int sid) { this.scooterId = sid; return this; }
        public Builder maintainerId(Integer mid) { this.maintainerId = mid; return this; }
        public Builder scheduledDate(LocalDate d) { this.scheduledDate = d; return this; }
        public Builder completedDate(LocalDate d) { this.completedDate = d; return this; }
        public Builder status(Status s) { this.status = s; return this; }
        public Builder notes(String n) { this.notes = n; return this; }

        public MaintenanceTask build() { return new MaintenanceTask(this); }
    }

    public int getTaskId() { return taskId; }
    public Integer getAlertId() { return alertId; }
    public int getScooterId() { return scooterId; }
    public Integer getMaintainerId() { return maintainerId; }
    public LocalDate getScheduledDate() { return scheduledDate; }
    public LocalDate getCompletedDate() { return completedDate; }
    public Status getStatus() { return status; }
    public String getNotes() { return notes; }
}
