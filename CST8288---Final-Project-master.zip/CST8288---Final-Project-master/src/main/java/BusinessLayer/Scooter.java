/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

/**
 *
 * @author sethb
 */
public class Scooter {
    public enum Status { AVAILABLE, IN_USE, CHARGING, MAINTENANCE}

    private int id;
    private String vehicleNumber;
    private String make;
    private String model;
    private String color;
    private int batteryCapacity;
    private int sponsorUserId;
    private Status status;

    // Private constructor – only Builder can create
    private Scooter(Builder b) {
        this.id = b.id;
        this.vehicleNumber = b.vehicleNumber;
        this.make = b.make;
        this.model = b.model;
        this.color = b.color;
        this.batteryCapacity = b.batteryCapacity;
        this.sponsorUserId = b.sponsorUserId;
        this.status = b.status;
    }

    // Build pattern
    public static class Builder {
        private int id;
        private String vehicleNumber;
        private String make;
        private String model;
        private String color;
        private int batteryCapacity;
        private int sponsorUserId;
        private Status status = Status.AVAILABLE;

        public Builder id(int id) { this.id = id; return this; }
        public Builder vehicleNumber(String v) { this.vehicleNumber = v; return this; }
        public Builder make(String m) { this.make = m; return this; }
        public Builder model(String m) { this.model = m; return this; }
        public Builder color(String c) { this.color = c; return this; }
        public Builder batteryCapacity(int cap) { this.batteryCapacity = cap; return this; }
        public Builder sponsorUserId(int sponsorId) { this.sponsorUserId = sponsorId; return this; }
        public Builder status(Status s) { this.status = s; return this; }

        public Scooter build() { return new Scooter(this); }
    }

    // Getters
    public int getId() { return id; }
    public String getVehicleNumber() { return vehicleNumber; }
    public String getMake() { return make; }
    public String getModel() { return model; }
    public String getColor() { return color; }
    public int getBatteryCapacity() { return batteryCapacity; }
    public int getSponsorUserId() { return sponsorUserId; }
    public Status getStatus() { return status; }
}
