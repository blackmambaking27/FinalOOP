/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

/**
 *
 * @author sethb
 * Adapter Pattern – Adapter class.
 * Adapts the Scooter domain object to the EnergyInfo interface
 * used by the energy reporting logic.
 */
public class ScooterEnergyAdapter implements EnergyInfo {

    private final Scooter scooter;

    public ScooterEnergyAdapter(Scooter scooter) {
        this.scooter = scooter;
    }

    @Override
    public String getVehicleNumber() {
        return scooter.getVehicleNumber();
    }

    @Override
    public int getBatteryCapacity() {
        int capacity = scooter.getBatteryCapacity();
        return (capacity > 0) ? capacity : 250; // default if not set
    }

    @Override
    public int getCurrentChargePercent() {
        // Same deterministic logic you used before, but now encapsulated here
        int id = scooter.getId();
        int currentCharge = (40 + (id * 13)) % 101;
        if (currentCharge < 10) {
            currentCharge += 15;
        }
        return currentCharge;
    }

    @Override
    public int getMinutesToFull() {
        int missing = 100 - getCurrentChargePercent();
        return missing * 2; // pretend 2 minutes per 1%
    }

    @Override
    public int getEstimatedRangeKm() {
        int capacity = getBatteryCapacity();
        int current = getCurrentChargePercent();
        return (capacity / 10) * current / 100;
    }
}