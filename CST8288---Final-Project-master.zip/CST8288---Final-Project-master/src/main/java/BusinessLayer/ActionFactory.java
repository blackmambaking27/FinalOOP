package BusinessLayer;

/**
 * Factory that creates Action objects based on the "action" parameter.
 */
public class ActionFactory {

    public static Action create(String action) {
        if (action == null) {
            // Default: show login page
            return new ShowLoginAction();
        }

        switch (action) {
            case "showLogin":
                return new ShowLoginAction();

            case "showRegister":
                return new ShowRegisterAction();

            case "registerUser":
                return new RegisterUserAction();

            case "login":
                return new LoginAction();

            case "dashboard":
                return new DashboardAction();

            case "showRegisterScooter":
                return new ShowRegisterScooterAction();

            case "registerScooter":
                return new RegisterScooterAction();

            case "viewSponsorScooters":
                return new ViewSponsorScootersAction();

            case "viewScooterStatus":
                return new ViewScooterStatusAction();

            case "viewEnergyReport":
                return new ViewEnergyReportAction();

            case "viewMaintenanceAlerts":
                return new ViewMaintenanceAlertsAction();

            case "viewAccount":
                return new ViewAccountAction();

            case "viewChargingStations":
                return new ViewChargingStationsAction();

            case "logout":
                return new LogoutAction();

            default:
                // Unknown action → go to login
                return new ShowLoginAction();
        }
    }
}
