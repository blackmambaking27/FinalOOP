package BusinessLayer;

public class ChargingStation {

    private final int stationId;
    private final String name;
    private final String locationDescription;
    private final int maxCapacity;

    private ChargingStation(Builder b) {
        this.stationId = b.stationId;
        this.name = b.name;
        this.locationDescription = b.locationDescription;
        this.maxCapacity = b.maxCapacity;
    }

    public static class Builder {
        private int stationId;
        private String name;
        private String locationDescription;
        private int maxCapacity;

        public Builder stationId(int id) { this.stationId = id; return this; }
        public Builder name(String n) { this.name = n; return this; }
        public Builder locationDescription(String d) { this.locationDescription = d; return this; }
        public Builder maxCapacity(int c) { this.maxCapacity = c; return this; }

        public ChargingStation build() { return new ChargingStation(this); }
    }

    public int getStationId() { return stationId; }
    public String getName() { return name; }
    public String getLocationDescription() { return locationDescription; }
    public int getMaxCapacity() { return maxCapacity; }
}
