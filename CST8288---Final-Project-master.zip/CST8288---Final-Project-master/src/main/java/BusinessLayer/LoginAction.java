/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

import DataAccessLayer.UserDAO;
import DataAccessLayer.UserDAOImp;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author sethb
 */
public class LoginAction implements Action {

    private final UserDAO userDAO = new UserDAOImp();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String pw    = request.getParameter("password");

        try {
            User u = userDAO.findByEmail(email);

            if (u == null || !u.getPassword().equals(pw)) {
                request.setAttribute("error", "Invalid email or password.");
                request.getRequestDispatcher("/WEB-INF/jsp/login.jsp")
                       .forward(request, response);
                return;
            }

            HttpSession session = request.getSession();
            session.setAttribute("currentUser", u);

            response.sendRedirect("controller?action=dashboard");

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
