package BusinessLayer;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Trip {

    private final int tripId;
    private final int userId;
    private final int scooterId;
    private final Integer startStationId;
    private final Integer endStationId;
    private final LocalDateTime startTime;
    private final LocalDateTime endTime;
    private final BigDecimal distanceKm;
    private final Integer minutesAwayFromStation;
    private final BigDecimal debitAmount;

    private Trip(Builder b) {
        this.tripId = b.tripId;
        this.userId = b.userId;
        this.scooterId = b.scooterId;
        this.startStationId = b.startStationId;
        this.endStationId = b.endStationId;
        this.startTime = b.startTime;
        this.endTime = b.endTime;
        this.distanceKm = b.distanceKm;
        this.minutesAwayFromStation = b.minutesAwayFromStation;
        this.debitAmount = b.debitAmount;
    }

    public static class Builder {
        private int tripId;
        private int userId;
        private int scooterId;
        private Integer startStationId;
        private Integer endStationId;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private BigDecimal distanceKm;
        private Integer minutesAwayFromStation;
        private BigDecimal debitAmount;

        public Builder tripId(int id) { this.tripId = id; return this; }
        public Builder userId(int uid) { this.userId = uid; return this; }
        public Builder scooterId(int sid) { this.scooterId = sid; return this; }
        public Builder startStationId(Integer id) { this.startStationId = id; return this; }
        public Builder endStationId(Integer id) { this.endStationId = id; return this; }
        public Builder startTime(LocalDateTime t) { this.startTime = t; return this; }
        public Builder endTime(LocalDateTime t) { this.endTime = t; return this; }
        public Builder distanceKm(BigDecimal d) { this.distanceKm = d; return this; }
        public Builder minutesAwayFromStation(Integer m) { this.minutesAwayFromStation = m; return this; }
        public Builder debitAmount(BigDecimal d) { this.debitAmount = d; return this; }

        public Trip build() { return new Trip(this); }
    }

    public int getTripId() { return tripId; }
    public int getUserId() { return userId; }
    public int getScooterId() { return scooterId; }
    public Integer getStartStationId() { return startStationId; }
    public Integer getEndStationId() { return endStationId; }
    public LocalDateTime getStartTime() { return startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public BigDecimal getDistanceKm() { return distanceKm; }
    public Integer getMinutesAwayFromStation() { return minutesAwayFromStation; }
    public BigDecimal getDebitAmount() { return debitAmount; }
}
