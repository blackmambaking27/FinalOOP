/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

import DataAccessLayer.UserDAO;
import DataAccessLayer.UserDAOImp;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author sethb
 */
public class RegisterUserAction implements Action {

    private final UserDAO userDAO = new UserDAOImp();

    @Override
public void execute(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    try {
        String name  = request.getParameter("name");
        String email = request.getParameter("email");
        String pw    = request.getParameter("password");
        String type  = request.getParameter("userType"); // USER / SPONSOR / MAINTAINER

        User user = UserFactory.createUser(name, email, pw, type);
        userDAO.create(user);

        // On success, go to login page with a message
        request.setAttribute("message", "Registration successful! Please log in.");
        request.getRequestDispatcher("/WEB-INF/jsp/login.jsp")
               .forward(request, response);

    } catch (Exception e) {
        e.printStackTrace();
        request.setAttribute("error", e.getClass().getName() + ": " + e.getMessage());
        request.getRequestDispatcher("/WEB-INF/jsp/register.jsp")
               .forward(request, response);
    }
}

}