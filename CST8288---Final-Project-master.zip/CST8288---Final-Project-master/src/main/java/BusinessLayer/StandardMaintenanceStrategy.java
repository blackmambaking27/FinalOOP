/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

/**
 *
 * @author sethb
 * Concrete Strategy: evaluates maintenance based on simulated wear metrics.
 */
public class StandardMaintenanceStrategy implements MaintenanceStrategy {

    public MaintenanceStatus evaluate(Scooter scooter) {
        // Simulated metrics
        int id = scooter.getId();

        // Simulated total hours of use for this scooter
        int hoursOfUse = (id * 37) % 500;         // 0–499 hours
        int brakeWear  = (id * 21) % 100;         // 0–99 %
        int tireWear   = (id * 17) % 100;         // 0–99 %

        MaintenanceStatus.Level level;
        String message;

        if (hoursOfUse > 400 || brakeWear > 80 || tireWear > 80) {
            level = MaintenanceStatus.Level.OVERDUE;
            message = "Service overdue: schedule maintenance immediately.";
        } else if (hoursOfUse > 250 || brakeWear > 60 || tireWear > 60) {
            level = MaintenanceStatus.Level.DUE_SOON;
            message = "Service due soon: plan maintenance in the next few days.";
        } else {
            level = MaintenanceStatus.Level.OK;
            message = "No immediate maintenance required.";
        }

        return new MaintenanceStatus(level, message, hoursOfUse, brakeWear, tireWear);
    }
}