package BusinessLayer;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class EnergyReading {

    private final int readingId;
    private final int scooterId;
    private final LocalDateTime readingTime;
    private final int chargePercent;
    private final Integer timeToFullMinutes;
    private final BigDecimal energyUsedKwh;

    private EnergyReading(Builder b) {
        this.readingId = b.readingId;
        this.scooterId = b.scooterId;
        this.readingTime = b.readingTime;
        this.chargePercent = b.chargePercent;
        this.timeToFullMinutes = b.timeToFullMinutes;
        this.energyUsedKwh = b.energyUsedKwh;
    }

    public static class Builder {
        private int readingId;
        private int scooterId;
        private LocalDateTime readingTime;
        private int chargePercent;
        private Integer timeToFullMinutes;
        private BigDecimal energyUsedKwh;

        public Builder readingId(int id) { this.readingId = id; return this; }
        public Builder scooterId(int id) { this.scooterId = id; return this; }
        public Builder readingTime(LocalDateTime t) { this.readingTime = t; return this; }
        public Builder chargePercent(int p) { this.chargePercent = p; return this; }
        public Builder timeToFullMinutes(Integer m) { this.timeToFullMinutes = m; return this; }
        public Builder energyUsedKwh(BigDecimal e) { this.energyUsedKwh = e; return this; }

        public EnergyReading build() { return new EnergyReading(this); }
    }

    public int getReadingId() { return readingId; }
    public int getScooterId() { return scooterId; }
    public LocalDateTime getReadingTime() { return readingTime; }
    public int getChargePercent() { return chargePercent; }
    public Integer getTimeToFullMinutes() { return timeToFullMinutes; }
    public BigDecimal getEnergyUsedKwh() { return energyUsedKwh; }
}
