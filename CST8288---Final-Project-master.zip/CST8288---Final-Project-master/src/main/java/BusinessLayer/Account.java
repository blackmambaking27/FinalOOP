package BusinessLayer;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Account {

    private final int accountId;
    private final int userId;
    private final BigDecimal currentBalance;
    private final LocalDate lastStatementDate;

    private Account(Builder b) {
        this.accountId = b.accountId;
        this.userId = b.userId;
        this.currentBalance = b.currentBalance;
        this.lastStatementDate = b.lastStatementDate;
    }

    public static class Builder {
        private int accountId;
        private int userId;
        private BigDecimal currentBalance = BigDecimal.ZERO;
        private LocalDate lastStatementDate;

        public Builder accountId(int id) { this.accountId = id; return this; }
        public Builder userId(int uid) { this.userId = uid; return this; }
        public Builder currentBalance(BigDecimal bal) { this.currentBalance = bal; return this; }
        public Builder lastStatementDate(LocalDate date) { this.lastStatementDate = date; return this; }

        public Account build() { return new Account(this); }
    }

    public int getAccountId() { return accountId; }
    public int getUserId() { return userId; }
    public BigDecimal getCurrentBalance() { return currentBalance; }
    public LocalDate getLastStatementDate() { return lastStatementDate; }
}
