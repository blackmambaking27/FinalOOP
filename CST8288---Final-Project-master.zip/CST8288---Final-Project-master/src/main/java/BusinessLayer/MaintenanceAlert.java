package BusinessLayer;

import java.time.LocalDateTime;

public class MaintenanceAlert {

    private final int alertId;
    private final int scooterId;
    private final LocalDateTime createdAt;
    private final String alertType;
    private final String description;
    private final boolean active;

    private MaintenanceAlert(Builder b) {
        this.alertId = b.alertId;
        this.scooterId = b.scooterId;
        this.createdAt = b.createdAt;
        this.alertType = b.alertType;
        this.description = b.description;
        this.active = b.active;
    }

    public static class Builder {
        private int alertId;
        private int scooterId;
        private LocalDateTime createdAt;
        private String alertType;
        private String description;
        private boolean active = true;

        public Builder alertId(int id) { this.alertId = id; return this; }
        public Builder scooterId(int sid) { this.scooterId = sid; return this; }
        public Builder createdAt(LocalDateTime t) { this.createdAt = t; return this; }
        public Builder alertType(String t) { this.alertType = t; return this; }
        public Builder description(String d) { this.description = d; return this; }
        public Builder active(boolean a) { this.active = a; return this; }

        public MaintenanceAlert build() { return new MaintenanceAlert(this); }
    }

    public int getAlertId() { return alertId; }
    public int getScooterId() { return scooterId; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public String getAlertType() { return alertType; }
    public String getDescription() { return description; }
    public boolean isActive() { return active; }
}
