package BusinessLayer;

import BusinessLayer.User.UserType;
import BusinessLayer.Scooter.Status;
import DataAccessLayer.ScooterDAO;
import DataAccessLayer.ScooterDAOImp;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Marks a scooter as IN_USE for a student renting it.
 * (We just change status; you can later add Trip records if needed.)
 */
public class RentScooterAction implements Action {

    private final ScooterDAO scooterDAO = new ScooterDAOImp();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User current = (session == null) ? null : (User) session.getAttribute("currentUser");

        if (current == null || current.getUserType() != UserType.USER) {
            response.sendRedirect("controller?action=showLogin");
            return;
        }

        String idParam = request.getParameter("scooterId");
        if (idParam == null) {
            // No scooter specified → go back to list
            response.sendRedirect("controller?action=showRentScooter");
            return;
        }

        try {
            int scooterId = Integer.parseInt(idParam);

            // Mark scooter as IN_USE
            scooterDAO.updateStatus(scooterId, Status.IN_USE);

            // Optional: later we could create a Trip row here

            // Redirect back to account or list
            response.sendRedirect("controller?action=viewAccount");

        } catch (Exception e) {
            throw new ServletException("Error renting scooter", e);
        }
    }
}
