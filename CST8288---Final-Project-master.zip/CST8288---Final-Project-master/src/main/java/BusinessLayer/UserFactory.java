/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

import BusinessLayer.User.UserType;

/**
 *
 * @author sethb
 */
public class UserFactory {
    
    // Simple Factory: creates a User based on type string
    public static User createUser(String name, String email, String password, String type) {
        // type will be "USER", "SPONSOR", or "MAINTAINER"
        UserType userType = UserType.valueOf(type);

        return new User.Builder()
                .name(name)
                .email(email)
                .password(password) 
                .userType(userType)
                .build();
    }
}
