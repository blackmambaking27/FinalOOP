/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusinessLayer;

/**
 *
 * @author sethb
 */
public class MaintenanceStatus {

    public enum Level { OK, DUE_SOON, OVERDUE }

    private final Level level;
    private final String message;
    private final int hoursOfUse;
    private final int brakeWearPercent;
    private final int tireWearPercent;

    public MaintenanceStatus(Level level,
                             String message,
                             int hoursOfUse,
                             int brakeWearPercent,
                             int tireWearPercent) {
        this.level = level;
        this.message = message;
        this.hoursOfUse = hoursOfUse;
        this.brakeWearPercent = brakeWearPercent;
        this.tireWearPercent = tireWearPercent;
    }

    public Level getLevel() {
        return level;
    }

    public String getMessage() {
        return message;
    }

    public int getHoursOfUse() {
        return hoursOfUse;
    }

    public int getBrakeWearPercent() {
        return brakeWearPercent;
    }

    public int getTireWearPercent() {
        return tireWearPercent;
    }
}
