package DataAccessLayer;

import BusinessLayer.User;
import BusinessLayer.User.UserType;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of UserDAO using JDBC and MySQL.
 * Maps to table "user" in the "scooter" schema.
 */
public class UserDAOImp implements UserDAO {

    private final DBConnectionManager connectionManager;

    // Default constructor used by your Actions (LoginAction, RegisterUserAction, etc.)
    public UserDAOImp() {
        this(new DBConnectionManager());
    }

    public UserDAOImp(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(User user) throws Exception {
        String sql = "INSERT INTO user (full_name, email, password_hash, user_type) VALUES (?,?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getUserType().name());

            ps.executeUpdate();
        }
    }

    @Override
    public User findByEmail(String email) throws Exception {
        String sql = "SELECT * FROM user WHERE email = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public User findById(int id) throws Exception {
        String sql = "SELECT * FROM user WHERE user_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<User> findAll() throws Exception {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM user";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private User mapRow(ResultSet rs) throws Exception {
        String typeStr = rs.getString("user_type");
        UserType type = UserType.valueOf(typeStr); // includes ADMIN now

        return new User.Builder()
                .id(rs.getInt("user_id"))
                .name(rs.getString("full_name"))
                .email(rs.getString("email"))
                .password(rs.getString("password_hash"))
                .userType(type)
                .build();
    }
}
