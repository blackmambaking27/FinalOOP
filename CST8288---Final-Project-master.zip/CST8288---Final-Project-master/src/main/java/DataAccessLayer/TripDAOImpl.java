package DataAccessLayer;

import BusinessLayer.Trip;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TripDAOImpl implements TripDAO {

    private final DBConnectionManager connectionManager;

    public TripDAOImpl() {
        this(new DBConnectionManager());
    }

    public TripDAOImpl(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(Trip trip) throws Exception {
        String sql = "INSERT INTO trip " +
                "(user_id, scooter_id, start_station_id, end_station_id, " +
                " start_time, end_time, distance_km, minutes_away_from_station, debit_amount) " +
                "VALUES (?,?,?,?,?,?,?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, trip.getUserId());
            ps.setInt(2, trip.getScooterId());

            if (trip.getStartStationId() != null) {
                ps.setInt(3, trip.getStartStationId());
            } else {
                ps.setNull(3, Types.INTEGER);
            }

            if (trip.getEndStationId() != null) {
                ps.setInt(4, trip.getEndStationId());
            } else {
                ps.setNull(4, Types.INTEGER);
            }

            ps.setTimestamp(5, Timestamp.valueOf(trip.getStartTime()));

            if (trip.getEndTime() != null) {
                ps.setTimestamp(6, Timestamp.valueOf(trip.getEndTime()));
            } else {
                ps.setNull(6, Types.TIMESTAMP);
            }

            if (trip.getDistanceKm() != null) {
                ps.setBigDecimal(7, trip.getDistanceKm());
            } else {
                ps.setNull(7, Types.DECIMAL);
            }

            if (trip.getMinutesAwayFromStation() != null) {
                ps.setInt(8, trip.getMinutesAwayFromStation());
            } else {
                ps.setNull(8, Types.INTEGER);
            }

            ps.setBigDecimal(9, trip.getDebitAmount() != null
                    ? trip.getDebitAmount()
                    : BigDecimal.ZERO);

            ps.executeUpdate();
            // No trip.setTripId(...)
        }
    }

    @Override
    public Trip findById(int tripId) throws Exception {
        String sql = "SELECT * FROM trip WHERE trip_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, tripId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Trip> findByUserId(int userId) throws Exception {
        List<Trip> list = new ArrayList<>();
        String sql = "SELECT * FROM trip WHERE user_id = ? ORDER BY start_time DESC";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public List<Trip> findByScooterId(int scooterId) throws Exception {
        List<Trip> list = new ArrayList<>();
        String sql = "SELECT * FROM trip WHERE scooter_id = ? ORDER BY start_time DESC";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooterId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public List<Trip> findAll() throws Exception {
        List<Trip> list = new ArrayList<>();
        String sql = "SELECT * FROM trip";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private Trip mapRow(ResultSet rs) throws Exception {
        Timestamp startTs = rs.getTimestamp("start_time");
        Timestamp endTs = rs.getTimestamp("end_time");
        LocalDateTime start = startTs != null ? startTs.toLocalDateTime() : null;
        LocalDateTime end = endTs != null ? endTs.toLocalDateTime() : null;

        return new Trip.Builder()
                .tripId(rs.getInt("trip_id"))
                .userId(rs.getInt("user_id"))
                .scooterId(rs.getInt("scooter_id"))
                .startStationId((Integer) rs.getObject("start_station_id"))
                .endStationId((Integer) rs.getObject("end_station_id"))
                .startTime(start)
                .endTime(end)
                .distanceKm(rs.getBigDecimal("distance_km"))
                .minutesAwayFromStation((Integer) rs.getObject("minutes_away_from_station"))
                .debitAmount(rs.getBigDecimal("debit_amount"))
                .build();
    }
}
