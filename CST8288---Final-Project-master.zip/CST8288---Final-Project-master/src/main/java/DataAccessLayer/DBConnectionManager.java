package DataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages JDBC connections to the MySQL database.
 * 
 * Instance-based: DAOs each hold their own DBConnectionManager instance.
 */
public class DBConnectionManager {

    private final String url;
    private final String user;
    private final String pass;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Failed to load MySQL JDBC driver", e);
        }
    }

    // Default: matches Scooterdatabse.sql (database name = scooter)
    public DBConnectionManager() {
        this(
            "jdbc:mysql://localhost:3306/scooter"
                + "?allowPublicKeyRetrieval=true"
                + "&useSSL=false"
                + "&serverTimezone=UTC",
            "cst8288",
            "cst8288"   // change if your password is different
        );
    }

    public DBConnectionManager(String url, String user, String pass) {
        this.url = url;
        this.user = user;
        this.pass = pass;
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, pass);
    }
}
