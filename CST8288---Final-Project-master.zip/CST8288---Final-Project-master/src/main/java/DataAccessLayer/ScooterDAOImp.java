package DataAccessLayer;

import BusinessLayer.Scooter;
import BusinessLayer.Scooter.Status;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO implementation for Scooter.
 * Maps to table "scooter" in the "scooter" schema.
 */
public class ScooterDAOImp implements ScooterDAO {

    private final DBConnectionManager connectionManager;

    // Used in your Actions: new ScooterDAOImp()
    public ScooterDAOImp() {
        this(new DBConnectionManager());
    }

    public ScooterDAOImp(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(Scooter scooter) throws Exception {
        String sql = "INSERT INTO scooter " +
                "(sponsor_id, make, model, vehicle_number, colour, battery_capacity_kwh, status) " +
                "VALUES (?,?,?,?,?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooter.getSponsorUserId());
            ps.setString(2, scooter.getMake());
            ps.setString(3, scooter.getModel());
            ps.setString(4, scooter.getVehicleNumber());
            ps.setString(5, scooter.getColor());

            // Convert Wh (int) -> kWh (DECIMAL)
            BigDecimal kwh = BigDecimal.valueOf(scooter.getBatteryCapacity())
                                      .movePointLeft(3); // /1000
            ps.setBigDecimal(6, kwh);

            ps.setString(7, scooter.getStatus().name()); // Status enum now matches DB

            ps.executeUpdate();
        }
    }

    @Override
    public Scooter findByVehicleNumber(String vehicleNumber) throws Exception {
        String sql = "SELECT * FROM scooter WHERE vehicle_number = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, vehicleNumber);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Scooter> findBySponsor(int sponsorUserId) throws Exception {
        List<Scooter> list = new ArrayList<>();
        String sql = "SELECT * FROM scooter WHERE sponsor_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, sponsorUserId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public List<Scooter> findAll() throws Exception {
        List<Scooter> list = new ArrayList<>();
        String sql = "SELECT * FROM scooter";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private Scooter mapRow(ResultSet rs) throws Exception {
        BigDecimal kwh = rs.getBigDecimal("battery_capacity_kwh");
        int wh = kwh == null ? 0 : kwh.movePointRight(3).intValue(); // kWh -> Wh

        Status status = Status.valueOf(rs.getString("status"));

        return new Scooter.Builder()
                .id(rs.getInt("scooter_id"))
                .sponsorUserId(rs.getInt("sponsor_id"))
                .make(rs.getString("make"))
                .model(rs.getString("model"))
                .vehicleNumber(rs.getString("vehicle_number"))
                .color(rs.getString("colour"))
                .batteryCapacity(wh)
                .status(status)
                .build();
    }
}
