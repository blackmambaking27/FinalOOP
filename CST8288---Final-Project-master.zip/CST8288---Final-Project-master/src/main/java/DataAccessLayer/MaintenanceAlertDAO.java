package DataAccessLayer;

import BusinessLayer.MaintenanceAlert;
import java.util.List;

public interface MaintenanceAlertDAO {

    void create(MaintenanceAlert alert) throws Exception;

    MaintenanceAlert findById(int alertId) throws Exception;

    List<MaintenanceAlert> findActiveByScooterId(int scooterId) throws Exception;

    List<MaintenanceAlert> findAllActive() throws Exception;

    void update(MaintenanceAlert alert) throws Exception;
}
