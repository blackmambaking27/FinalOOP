package DataAccessLayer;

import BusinessLayer.MaintenanceTask;
import BusinessLayer.MaintenanceTask.Status;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MaintenanceTaskDAOImp implements MaintenanceTaskDAO {

    private final DBConnectionManager connectionManager;

    public MaintenanceTaskDAOImp() {
        this(new DBConnectionManager());
    }

    public MaintenanceTaskDAOImp(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(MaintenanceTask task) throws Exception {
        String sql = "INSERT INTO maintenance_task " +
                "(alert_id, scooter_id, maintainer_id, scheduled_date, " +
                " completed_date, status, notes) " +
                "VALUES (?,?,?,?,?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // alert_id (nullable)
            if (task.getAlertId() != null) {
                ps.setInt(1, task.getAlertId());
            } else {
                ps.setNull(1, Types.INTEGER);
            }

            // scooter_id (NOT NULL)
            ps.setInt(2, task.getScooterId());

            // maintainer_id (nullable)
            if (task.getMaintainerId() != null) {
                ps.setInt(3, task.getMaintainerId());
            } else {
                ps.setNull(3, Types.INTEGER);
            }

            // scheduled_date (nullable)
            if (task.getScheduledDate() != null) {
                ps.setDate(4, Date.valueOf(task.getScheduledDate()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            // completed_date (nullable)
            if (task.getCompletedDate() != null) {
                ps.setDate(5, Date.valueOf(task.getCompletedDate()));
            } else {
                ps.setNull(5, Types.DATE);
            }

            ps.setString(6, task.getStatus().name());
            ps.setString(7, task.getNotes());

            ps.executeUpdate();
            // ⚠️ No task.setTaskId(...); MaintenanceTask is immutable (builder only)
        }
    }

    @Override
    public MaintenanceTask findById(int taskId) throws Exception {
        String sql = "SELECT * FROM maintenance_task WHERE task_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, taskId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<MaintenanceTask> findByScooterId(int scooterId) throws Exception {
        List<MaintenanceTask> list = new ArrayList<>();
        String sql = "SELECT * FROM maintenance_task WHERE scooter_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooterId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public List<MaintenanceTask> findByMaintainerId(int maintainerId) throws Exception {
        List<MaintenanceTask> list = new ArrayList<>();
        String sql = "SELECT * FROM maintenance_task WHERE maintainer_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maintainerId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public void update(MaintenanceTask task) throws Exception {
        String sql = "UPDATE maintenance_task SET " +
                "alert_id = ?, scooter_id = ?, maintainer_id = ?, " +
                "scheduled_date = ?, completed_date = ?, status = ?, notes = ? " +
                "WHERE task_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (task.getAlertId() != null) {
                ps.setInt(1, task.getAlertId());
            } else {
                ps.setNull(1, Types.INTEGER);
            }

            ps.setInt(2, task.getScooterId());

            if (task.getMaintainerId() != null) {
                ps.setInt(3, task.getMaintainerId());
            } else {
                ps.setNull(3, Types.INTEGER);
            }

            if (task.getScheduledDate() != null) {
                ps.setDate(4, Date.valueOf(task.getScheduledDate()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            if (task.getCompletedDate() != null) {
                ps.setDate(5, Date.valueOf(task.getCompletedDate()));
            } else {
                ps.setNull(5, Types.DATE);
            }

            ps.setString(6, task.getStatus().name());
            ps.setString(7, task.getNotes());
            ps.setInt(8, task.getTaskId());

            ps.executeUpdate();
        }
    }

    private MaintenanceTask mapRow(ResultSet rs) throws Exception {
        Date sched = rs.getDate("scheduled_date");
        Date comp = rs.getDate("completed_date");
        LocalDate schedDate = (sched != null) ? sched.toLocalDate() : null;
        LocalDate compDate  = (comp != null) ? comp.toLocalDate() : null;

        return new MaintenanceTask.Builder()
                .taskId(rs.getInt("task_id"))
                .alertId((Integer) rs.getObject("alert_id"))
                .scooterId(rs.getInt("scooter_id"))
                .maintainerId((Integer) rs.getObject("maintainer_id"))
                .scheduledDate(schedDate)
                .completedDate(compDate)
                .status(Status.valueOf(rs.getString("status")))
                .notes(rs.getString("notes"))
                .build();
    }
}
