package DataAccessLayer;

import BusinessLayer.MaintenanceTask;
import java.util.List;

public interface MaintenanceTaskDAO {

    void create(MaintenanceTask task) throws Exception;

    MaintenanceTask findById(int taskId) throws Exception;

    List<MaintenanceTask> findByScooterId(int scooterId) throws Exception;

    List<MaintenanceTask> findByMaintainerId(int maintainerId) throws Exception;

    void update(MaintenanceTask task) throws Exception;
}
