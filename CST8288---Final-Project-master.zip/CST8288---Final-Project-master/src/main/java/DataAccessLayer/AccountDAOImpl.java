package DataAccessLayer;

import BusinessLayer.Account;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDAOImpl implements AccountDAO {

    private final DBConnectionManager connectionManager;

    public AccountDAOImpl() {
        this(new DBConnectionManager());
    }

    public AccountDAOImpl(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(Account account) throws Exception {
        String sql = "INSERT INTO account (user_id, current_balance, last_statement_date) " +
                     "VALUES (?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, account.getUserId());
            ps.setBigDecimal(2, account.getCurrentBalance() != null
                    ? account.getCurrentBalance()
                    : BigDecimal.ZERO);

            if (account.getLastStatementDate() != null) {
                ps.setDate(3, Date.valueOf(account.getLastStatementDate()));
            } else {
                ps.setNull(3, Types.DATE);
            }

            ps.executeUpdate();
            // We do NOT call account.setAccountId(...); Account is immutable.
        }
    }

    @Override
    public Account findById(int accountId) throws Exception {
        String sql = "SELECT * FROM account WHERE account_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, accountId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public Account findByUserId(int userId) throws Exception {
        String sql = "SELECT * FROM account WHERE user_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public void update(Account account) throws Exception {
        String sql = "UPDATE account " +
                     "SET user_id = ?, current_balance = ?, last_statement_date = ? " +
                     "WHERE account_id = ?";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, account.getUserId());
            ps.setBigDecimal(2, account.getCurrentBalance());
            if (account.getLastStatementDate() != null) {
                ps.setDate(3, Date.valueOf(account.getLastStatementDate()));
            } else {
                ps.setNull(3, Types.DATE);
            }
            ps.setInt(4, account.getAccountId());

            ps.executeUpdate();
        }
    }

    @Override
    public List<Account> findAll() throws Exception {
        List<Account> list = new ArrayList<>();
        String sql = "SELECT * FROM account";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private Account mapRow(ResultSet rs) throws Exception {
        Date last = rs.getDate("last_statement_date");

        return new Account.Builder()
                .accountId(rs.getInt("account_id"))
                .userId(rs.getInt("user_id"))
                .currentBalance(rs.getBigDecimal("current_balance"))
                .lastStatementDate(last != null ? last.toLocalDate() : null)
                .build();
    }
}
