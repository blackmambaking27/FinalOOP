package DataAccessLayer;

import BusinessLayer.ScooterLocationHistory;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ScooterLocationHistoryDAOImpl implements ScooterLocationHistoryDAO {

    private final DBConnectionManager connectionManager;

    public ScooterLocationHistoryDAOImpl() {
        this(new DBConnectionManager());
    }

    public ScooterLocationHistoryDAOImpl(DBConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public void create(ScooterLocationHistory history) throws Exception {
        String sql = "INSERT INTO scooter_location_history " +
                "(scooter_id, station_id, location_desc, in_transit, recorded_at) " +
                "VALUES (?,?,?,?,?)";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, history.getScooterId());

            if (history.getStationId() != null) {
                ps.setInt(2, history.getStationId());
            } else {
                ps.setNull(2, Types.INTEGER);
            }

            ps.setString(3, history.getLocationDescription());
            ps.setBoolean(4, history.isInTransit());
            ps.setTimestamp(5, Timestamp.valueOf(history.getRecordedAt()));

            ps.executeUpdate();
            // No history.setHistoryId(...)
        }
    }

    @Override
    public List<ScooterLocationHistory> findByScooterId(int scooterId) throws Exception {
        List<ScooterLocationHistory> list = new ArrayList<>();
        String sql = "SELECT * FROM scooter_location_history " +
                     "WHERE scooter_id = ? ORDER BY recorded_at DESC";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooterId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public ScooterLocationHistory findLatestByScooterId(int scooterId) throws Exception {
        String sql = "SELECT * FROM scooter_location_history " +
                     "WHERE scooter_id = ? ORDER BY recorded_at DESC LIMIT 1";

        try (Connection conn = connectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, scooterId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    private ScooterLocationHistory mapRow(ResultSet rs) throws Exception {
        Timestamp ts = rs.getTimestamp("recorded_at");
        LocalDateTime recordedAt = ts != null ? ts.toLocalDateTime() : null;

        return new ScooterLocationHistory.Builder()
                .historyId(rs.getInt("history_id"))
                .scooterId(rs.getInt("scooter_id"))
                .stationId((Integer) rs.getObject("station_id"))
                .locationDescription(rs.getString("location_desc"))
                .inTransit(rs.getBoolean("in_transit"))
                .recordedAt(recordedAt)
                .build();
    }
}
