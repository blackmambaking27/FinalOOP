package DataAccessLayer;

import BusinessLayer.Scooter;
import java.util.List;

public interface ScooterDAO {

    void create(Scooter scooter) throws Exception;

    Scooter findByVehicleNumber(String vehicleNumber) throws Exception;

    List<Scooter> findBySponsor(int sponsorUserId) throws Exception;

    List<Scooter> findAll() throws Exception;
}
